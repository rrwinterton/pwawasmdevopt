import '../../models/heap_snapshot_model/heap_snapshot_model-legacy.js';
import './heap_snapshot_worker-entrypoint.js';
