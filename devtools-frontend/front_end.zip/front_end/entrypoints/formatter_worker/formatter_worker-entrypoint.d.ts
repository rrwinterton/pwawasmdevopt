import '../../third_party/codemirror/package/addon/runmode/runmode-standalone.js';
import '../../third_party/codemirror/package/mode/css/css.js';
import '../../third_party/codemirror/package/mode/xml/xml.js';
import '../../third_party/codemirror/package/mode/javascript/javascript.js';
