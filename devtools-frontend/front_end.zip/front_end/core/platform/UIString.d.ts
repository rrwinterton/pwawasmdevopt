declare class LocalizedStringTag {
    private localizationTag;
}
export declare type LocalizedString = string & LocalizedStringTag;
export declare const LocalizedEmptyString: LocalizedString;
export {};
