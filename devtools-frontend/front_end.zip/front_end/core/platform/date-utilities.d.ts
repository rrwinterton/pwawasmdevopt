export declare const isValid: (date: Date) => boolean;
export declare const toISO8601Compact: (date: Date) => string;
