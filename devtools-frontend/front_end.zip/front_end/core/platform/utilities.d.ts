export declare function runOnWindowLoad(callback: () => void): void;
export declare function assertNever(type: never, message: string): never;
