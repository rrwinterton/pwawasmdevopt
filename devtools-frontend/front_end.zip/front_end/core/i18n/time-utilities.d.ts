export declare const preciseMillisToString: (ms: number, precision?: number | undefined) => string;
export declare const millisToString: (ms: number, higherResolution?: boolean | undefined) => string;
export declare const secondsToString: (seconds: number, higherResolution?: boolean | undefined) => string;
